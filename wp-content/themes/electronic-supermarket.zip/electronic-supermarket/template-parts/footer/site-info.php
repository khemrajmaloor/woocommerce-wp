<?php
/**
 * Displays footer site info
 *
 * @package Electronic Supermarket
 * @subpackage electronic_supermarket
 */

?>

<div class="site-info">
	<div class="container">
        <p><?php electronic_supermarket_credit(); ?> <?php echo esc_html('By Themespride','electronic-supermarket'); ?> </p>
    </div>
</div>
